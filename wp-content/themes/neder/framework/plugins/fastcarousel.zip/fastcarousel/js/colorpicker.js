// JavaScript Document


		function colorpicker_init() {
			jQuery(document).ready(function( $ ){
				$(function() {
					$('#fc_main_color').wpColorPicker();
				});
			});	
		}
