// JavaScript Document

jQuery(document).ready(function($){

    $('.fg_main_color').wpColorPicker();

});